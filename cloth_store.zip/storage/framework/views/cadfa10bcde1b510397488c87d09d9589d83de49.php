<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<link href="<?php echo e(asset('assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-3 mb-3">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header header-elements-inline">
                    <h5 class="card-title">Announcements <a href="/create"><button class="ml-2 btn btn-success">New Announcement</button></a></h5>


				</div>
				<div class="card-body">
					See All Announcement
				</div>
				<table class="table datatable-basic">
					<thead>
						<tr>
							<th>Announcement text</th>
							<th>Announcement Date</th>

							<!--th>Status</th-->

						</tr>
					</thead>
					<tbody>

                        <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>


							<td><?php echo e($announcement->announcement_text); ?></td>
							<td><?php echo e($announcement->announcement_date); ?></td>


                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- Basic datatable -->
	<!-- /basic datatable -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Jdc\cloth_store (1)\cloth_store\resources\views/announcements/index.blade.php ENDPATH**/ ?>