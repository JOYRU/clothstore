<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<link href="<?php echo e(asset('assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h5>Admin Area:</h5>

<form>
    <div class="form-group">
      <label for="sel1">Select Task Subject:</label>

      <div>
      	<a href="/announcements">Announcement</a></br>
      	<a href="/products">Products</a></br>
      	<a href="/categories">Category</a></br>
      	<a href="#">Users</a></br>


      </div>




    </div>
  </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Jdc\cloth_store (1)\cloth_store\resources\views/admin.blade.php ENDPATH**/ ?>