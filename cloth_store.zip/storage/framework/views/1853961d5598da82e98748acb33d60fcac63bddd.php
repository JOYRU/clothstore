<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<link href="<?php echo e(asset('assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-3 mb-3">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header header-elements-inline">
                    <a href="/add" class="card-title btn btn-success">Add New Product </a>

				</div>
				<div class="card-body">
					<h5>See All Product</h5>
				</div>
				<table class="table datatable-basic">
					<thead>
						<tr>
							<th>Brand name</th>
							<th>Product Size</th>
							<th>Product Price </th>
							<th>Product Description</th>
							<th>Category Name</th>
							<th>Action</th>


							<!--th>Status</th-->

						</tr>
					</thead>
					<tbody>

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>


							<td><?php echo e($product->brand_name); ?></td>
							<td><?php echo e($product->product_size); ?></td>
							<td><?php echo e($product->product_price); ?></td>
							<td><?php echo e($product->product_description); ?></td>
							<td><?php echo e($product->category_id); ?></td>

							<td class="text-center">
								<div class="list-icons">
									<div class="dropdown">
										<a href="#" class="list-icons-item" data-toggle="dropdown">
											<i class="icon-menu9"></i>
										</a>
										<div class="dropdown-menu dropdown-menu-right">
                                           
											<a href="/edit/<?php echo e($product->id); ?>" class="dropdown-item"> Edit</a>
											<a href="/delete/<?php echo e($product->id); ?>" class="dropdown-item"> Delete</a>

										</div>
									</div>
								</div>
							</td>



                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- Basic datatable -->
	<!-- /basic datatable -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

	<!-- Theme JS files -->
	<script src="<?php echo e(asset('/global_assets/js/plugins/tables/datatables/datatables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/global_assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/page/room.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Jdc\cloth_store (1)\cloth_store\resources\views/products/index.blade.php ENDPATH**/ ?>