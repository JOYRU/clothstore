<?php $__env->startSection('jumburton'); ?>
<!-- Jumbotron -->
<div class="jumbotron text-white rounded-0 mb-0">
    <div class="container text-center">
        <h1 class="display-4 font-weight-thin"><span class="font-weight-light">Tracing</span> - Room Resources</h1>
        <p class="lead mb-4">With Virtual Tour</p>

    </div>
</div>
<!-- /jumbotron -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Main layout preview -->

<!-- /main layout preview -->
<!-- Project numbers -->

<!-- /project numbers -->
<!-- Child layouts preview -->
<div class="section bg-white border-top pt-5 pb-4">
    <div class="content container">
        <div class="section-title text-center mb-4 pb-3">
            <h1 class="mb-2 font-weight-light">Important Starting Point</h1>

        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-5 mr-md-3">
                    <div class="card-img-actions mb-4 shadow">
                        <img class="card-img img-fluid" src="<?php echo e(asset('landing/img/layout_2.png')); ?>" alt="">
                        <div class="card-img-actions-overlay card-img">
                            <div>
                                <div class="btn-toolbar justify-content-center">
                                    <div class="btn-group">
                                        <a href="#" class="btn bg-blue font-weight-semibold font-size-sm line-height-sm text-uppercase mb-1 shadow" target="_blank">
                                            Start Tour
                                        </a>
                                        <a href="#" class="btn bg-blue font-weight-semibold font-size-sm line-height-sm text-uppercase mb-1 shadow" target="_blank">
                                            see Details
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <h5 class="font-weight-semibold mb-2">
                         Deparment Office
                    </h5>

                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-5 ml-md-3">
                    <div class="card-img-actions mb-4 shadow">
                        <img class="card-img img-fluid" src="<?php echo e(asset('landing/img/layout_3.png')); ?>" alt="">
                        <div class="card-img-actions-overlay card-img">
                            <div>
                                <div class="btn-toolbar justify-content-center">
                                    <div class="btn-group">
                                        <a href="#" class="btn bg-blue font-weight-semibold font-size-sm line-height-sm text-uppercase mb-1 shadow" target="_blank">
                                            Start Tour
                                        </a>
                                        <a href="#" class="btn bg-blue font-weight-semibold font-size-sm line-height-sm text-uppercase mb-1 shadow" target="_blank">
                                            See Details
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <h5 class="font-weight-semibold mb-2">
                    Deparment Seminar Library</span>
                    </h5>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- /childs layouts preview -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\cloth_store\cloth_store\resources\views/welcome.blade.php ENDPATH**/ ?>