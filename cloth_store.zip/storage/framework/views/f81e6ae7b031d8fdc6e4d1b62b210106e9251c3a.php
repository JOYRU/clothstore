<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<link href="<?php echo e(asset('assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-3 mb-3">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header header-elements-inline">
                    <h5 class="card-title">Enter New Category</h5>


				</div>
				<div class="card-body">
                        <form class="form-horizontal" action="<?php echo e(route('category.update',$category->id)); ?>" method='post'>
                            <?php echo csrf_field(); ?>



                          <div class="form-group">
                              <label class="control-label col-sm-2" for="category_name">Category name:</label>
                              <div class="col-sm-10">
                                <input type="text " class="form-control" id="category_name" placeholder="Enter category_name" value="<?php echo e($category->category_name); ?>" name="category_name">
                              </div>
                            </div>





                            <div class="form-group">
                              <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-success">Submit</button>
                              </div>
                            </div>



                          </form>
				</div>

			</div>
		</div>
	</div>
	<!-- Basic datatable -->
	<!-- /basic datatable -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

	<!-- Theme JS files -->
	<script src="<?php echo e(asset('/global_assets/js/plugins/tables/datatables/datatables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/global_assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/page/room.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Jdc\cloth_store (1)\cloth_store\resources\views/category/edit.blade.php ENDPATH**/ ?>