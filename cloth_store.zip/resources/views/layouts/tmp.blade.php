                          <div class="form-group">
                              <label class="control-label col-sm-2" for="brand_name">Brand name:</label>
                              <div class="col-sm-10">
                                <input type="text " class="form-control" id="brand_name" placeholder="Enter brand_name" name="brand_name">
                              </div>
                            </div>

                            <div class="form-group">
                              <label class="control-label col-sm-2" for="product_size"> Product Size:</label>
                              <div class="col-sm-10">
                                <input type="text " class="form-control" id="product_size" placeholder="Enter product_size" name="product_size">
                              </div>
                            </div>


                              <div class="form-group">
                              <label class="control-label col-sm-2" for="product_price">Product Price:</label>
                              <div class="col-sm-10">
                                <input type="text " class="form-control" id="product_price" placeholder="Enter product_price" name="product_price">
                              </div>
                            </div>


                            <div class="form-group">
                              <label class="control-label col-sm-2" for="product_description">Product Price:</label>
                              <div class="col-sm-10">
                                <textarea class="form-control" rows = "2" id="product_description" placeholder="Enter product_description" name="product_description"></textarea>
                              </div>
                            </div>











                            <div class="form-group">
                              <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-default">Submit</button>
                              </div>
                            </div>